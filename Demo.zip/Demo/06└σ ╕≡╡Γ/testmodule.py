print("hello world")
defaultvalue = 2
def printDefaultValue():
    print(defaultvalue)
    
